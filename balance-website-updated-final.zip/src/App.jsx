import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import {
  ShoppingCart,
  Menu,
  X,
  Star,
  Heart,
  Truck,
  Shield,
  Leaf,
  Award,
  MapPin,
  Phone,
  Mail,
  Clock,
  Users,
  Package,
  ChefHat,
  Zap
} from 'lucide-react'
import logoImage from './assets/logo.jpg'
import './App.css'

// Sample product data
const products = [
  {
    id: "bal-protein-crackers-hot-pepper",
    name: "Balance بروتين كراكرز هوت بيبر",
    flavor: "Hot Pepper",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 280, protein_g: 15, carbs_g: 45, fat_g: 8 },
    price: 14.95,
    image: "/hot_pepper.png",
    badges: ["بروتين عالي", "مخبوز"],
    bestseller: true
  },
  {
    id: "bal-protein-crackers-lemon",
    name: "Balance بروتين كراكرز ليمون",
    flavor: "Lemon",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 285, protein_g: 15, carbs_g: 46, fat_g: 8 },
    price: 14.95,
    image: "/lemon.png",
    badges: ["بروتين عالي", "مخبوز"]
  },
  {
    id: "bal-protein-crackers-sweet-chili",
    name: "Balance بروتين كراكرز سويت تشيلي",
    flavor: "Sweet Chili",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 380, protein_g: 15, carbs_g: 50, fat_g: 12 },
    price: 16.00,
    image: "/sweet_chili.png",
    badges: ["بروتين عالي", "مطهو بالهواء"]
  },
  {
    id: "bal-protein-crackers-sour-cream-onion",
    name: "Balance بروتين كراكرز ساور كريم أونيون",
    flavor: "Sour Cream Onion",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 375, protein_g: 15, carbs_g: 48, fat_g: 11 },
    price: 16.00,
    image: "/sour_cream_onion.png",
    badges: ["بروتين عالي", "مطهو بالهواء"],
    new: true
  },
  {
    id: "bal-protein-crackers-cheese",
    name: "Balance بروتين كراكرز جبنة",
    flavor: "Cheese",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 378, protein_g: 15, carbs_g: 49, fat_g: 11 },
    price: 16.00,
    image: "/cheese.png",
    badges: ["بروتين عالي", "مطهو بالهواء"],
    new: true
  },
  {
    id: "bal-protein-crackers-sweet-corn",
    name: "Balance بروتين كراكرز ذرة حلوة",
    flavor: "Sweet Corn",
    base: "بروتين كراكرز",
    weight_g: 70,
    nutrition_per_100g: { kcal: 350, protein_g: 20, carbs_g: 40, fat_g: 10 },
    price: 25.00,
    image: "/sweet_corn.png",
    badges: ["بروتين عالي", "سناكس سريعة"],
    new: true
  },
  {
    id: "bal-protein-shots-sweet-corn",
    name: "Balance بروتين شوتس بطعم الذرة الحلوة",
    flavor: "Sweet Corn",
    base: "بروتين شوتس",
    weight_g: 70,
    nutrition_per_100g: { kcal: 280, protein_g: 20, carbs_g: 30, fat_g: 5 },
    price: 19.95,
    image: "/sweet_corn_shot.png",
    badges: ["بروتين عالي", "جديد"],
    new: true
  },
  {
    id: "bal-protein-shots-sweet-heat",
    name: "Balance بروتين شوتس بطعم سويت هيت",
    flavor: "Sweet Heat",
    base: "بروتين شوتس",
    weight_g: 70,
    nutrition_per_100g: { kcal: 280, protein_g: 20, carbs_g: 30, fat_g: 5 },
    price: 19.95,
    image: "/sweet_heat_shot.png",
    badges: ["بروتين عالي", "جديد"],
    new: true
  },
  {
    id: "bal-protein-shots-sweet-cheese",
    name: "Balance بروتين شوتس بطعم الجبنة الحلوة",
    flavor: "Sweet Cheese",
    base: "بروتين شوتس",
    weight_g: 70,
    nutrition_per_100g: { kcal: 280, protein_g: 20, carbs_g: 30, fat_g: 5 },
    price: 19.95,
    image: "/sweet_cheese_shot.png",
    badges: ["بروتين عالي", "جديد"],
    new: true
  }
];

function App() {
  const [currentPage, setCurrentPage] = useState('home')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [cart, setCart] = useState([])
  const [selectedProduct, setSelectedProduct] = useState(null)

  // Add to cart function
  const addToCart = (product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id)
      if (existing) {
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      }
      return [...prev, { ...product, quantity }]
    })
  }

  // Remove from cart
  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.id !== productId))
  }

  // Get cart total
  const getCartTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0)
  }

  // Header Component
  const Header = () => (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-md z-50 border-b border-gray-100">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button onClick={() => setCurrentPage('home')} className="flex items-center space-x-4 space-x-reverse">
            <img src={logoImage} alt="Balance Logo" className="h-10 w-auto" />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8 space-x-reverse">
            <button 
              onClick={() => setCurrentPage('home')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'home' ? 'text-blue-600 font-semibold' : ''}`}
            >
              الرئيسية
            </button>
            <button 
              onClick={() => setCurrentPage('products')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'products' ? 'text-blue-600 font-semibold' : ''}`}
            >
              المنتجات
            </button>
            <button 
              onClick={() => setCurrentPage('new-flavors')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'new-flavors' ? 'text-blue-600 font-semibold' : ''}`}
            >
              النكهات الجديدة
            </button>
            <button 
              onClick={() => setCurrentPage('about')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'about' ? 'text-blue-600 font-semibold' : ''}`}
            >
              من نحن
            </button>
            <button 
              onClick={() => setCurrentPage('wholesale')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'wholesale' ? 'text-blue-600 font-semibold' : ''}`}
            >
              الشراء بالجملة
            </button>
            <button 
              onClick={() => setCurrentPage('contact')}
              className={`text-gray-700 hover:text-blue-600 transition-colors ${currentPage === 'contact' ? 'text-blue-600 font-semibold' : ''}`}
            >
              تواصل معنا
            </button>
          </nav>

          {/* Cart and Mobile Menu */}
          <div className="flex items-center space-x-4 space-x-reverse">
            <button 
              onClick={() => setCurrentPage('cart')}
              className="relative p-2 text-gray-700 hover:text-blue-600 transition-colors"
            >
              <ShoppingCart className="h-6 w-6" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cart.reduce((total, item) => total + item.quantity, 0)}
                </span>
              )}
            </button>
            
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-700"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 py-4">
            <nav className="flex flex-col space-y-4">
              <button onClick={() => { setCurrentPage('home'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">الرئيسية</button>
              <button onClick={() => { setCurrentPage('products'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">المنتجات</button>
              <button onClick={() => { setCurrentPage('new-flavors'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">النكهات الجديدة</button>
              <button onClick={() => { setCurrentPage('about'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">من نحن</button>
              <button onClick={() => { setCurrentPage('wholesale'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">الشراء بالجملة</button>
              <button onClick={() => { setCurrentPage('contact'); setMobileMenuOpen(false) }} className="text-right text-gray-700 hover:text-blue-600">تواصل معنا</button>
            </nav>
          </div>
        )}
      </div>
    </header>
  )

  // Home Page Component
  const HomePage = () => (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="fade-in">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 gradient-text">
                الصحه بتبدأ من سناك
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                سناكس مخبوزة بمكوّنات طبيعية، بروح ألوان Balance. طعم قوي... مكونات أوعى.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => setCurrentPage('products')}
                  className="balance-button px-8 py-3 text-lg"
                >
                  تسوّق الآن
                </Button>
                <Button 
                  onClick={() => setCurrentPage('new-flavors')}
                  variant="outline" 
                  className="px-8 py-3 text-lg border-2 border-blue-500 text-blue-600 hover:bg-blue-50"
                >
                  اكتشف النكهات
                </Button>
              </div>
            </div>
            <div className="slide-in-right">
              <img 
                src="/logo_hero.jpg" 
                alt="Balance Products" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Event Section */}
      <section className="section-padding bg-gradient-to-r from-pink-50 to-orange-50">
        <div className="container-custom">
          <div className="balance-card p-8 text-center max-w-4xl mx-auto">
            <div className="gradient-bg text-white p-6 rounded-xl mb-6">
              <h2 className="text-3xl font-bold mb-4">نكهات جديدة قريبًا</h2>
              <p className="text-lg opacity-90">جرّب موجة الطعم الجديدة من Balance</p>
            </div>
            <p className="text-gray-600 mb-6 text-lg">
              بروتين شوتس، بافز، ورايس شيبس—طعم قوي، مكوّنات أوعى
            </p>
            <Button 
              onClick={() => setCurrentPage('new-flavors')}
              className="balance-button px-8 py-3"
            >
              جرّب الجديد
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section-padding">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12 gradient-text">منتجاتنا المميزة</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.slice(0, 4).map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="text-center mt-12">
            <Button 
              onClick={() => setCurrentPage('products')}
              className="balance-button px-8 py-3"
            >
              عرض جميع المنتجات
            </Button>
          </div>
        </div>
      </section>

      {/* Why Balance */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12 gradient-text">لماذا Balance؟</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<ChefHat className="h-8 w-8" />}
              title="مخبوز/مطهو بالهواء"
              description="بدلاً من القلي التقليدي"
            />
            <FeatureCard 
              icon={<Leaf className="h-8 w-8" />}
              title="مكوّنات طبيعية"
              description="من أجود المصادر الطبيعية"
            />
            <FeatureCard 
              icon={<Heart className="h-8 w-8" />}
              title="دهون أقل"
              description="صحة أكثر بطعم لذيذ"
            />
            <FeatureCard 
              icon={<Zap className="h-8 w-8" />}
              title="نكهات مبتكرة"
              description="تجربة طعم فريدة"
            />
          </div>
        </div>
      </section>

      {/* B2B Call to Action */}
      <section className="section-padding gradient-bg text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-4">عندك محل؟ اطلب بالجملة</h2>
          <p className="text-xl mb-8 opacity-90">أسعار خاصّة للتجار وأصحاب المحلات</p>
          <Button 
            onClick={() => setCurrentPage('wholesale')}
            className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 font-semibold"
          >
            الشراء بالجملة
          </Button>
        </div>
      </section>
    </div>
  )

  // Product Card Component
  const ProductCard = ({ product }) => (
    <div className="product-card p-6">
      <div className="relative mb-4">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-48 object-contain rounded-lg"
        />
        {product.bestseller && (
          <Badge className="absolute top-2 right-2 bg-yellow-500 text-white">
            الأكثر مبيعاً
          </Badge>
        )}
        {product.new && (
          <Badge className="absolute top-2 right-2 bg-green-500 text-white">
            جديد
          </Badge>
        )}
      </div>
      
      <h3 className="font-bold text-lg mb-2">{product.name}</h3>
      <p className="text-gray-600 mb-2">{product.flavor} • {product.weight_g}جم</p>
      
      <div className="flex flex-wrap gap-1 mb-4">
        {product.badges.map(badge => (
          <Badge key={badge} variant="secondary" className="text-xs">
            {badge}
          </Badge>
        ))}
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <span className="text-2xl font-bold text-blue-600">{product.price} ج.م</span>
        <Button 
          onClick={() => addToCart(product)}
          className="balance-button px-4 py-2 text-sm"
        >
          <ShoppingCart className="h-4 w-4 ml-2" /> أضف إلى السلة
        </Button>
      </div>
    </div>
  )

  // Product Page Component
  const ProductsPage = () => {
    const [searchTerm, setSearchTerm] = useState('')
    const [sortOrder, setSortOrder] = useState('default')

    const filteredProducts = products.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.flavor.toLowerCase().includes(searchTerm.toLowerCase())
    )

    const sortedProducts = [...filteredProducts].sort((a, b) => {
      if (sortOrder === 'price-asc') {
        return a.price - b.price
      } else if (sortOrder === 'price-desc') {
        return b.price - a.price
      } else if (sortOrder === 'name-asc') {
        return a.name.localeCompare(b.name)
      } else if (sortOrder === 'name-desc') {
        return b.name.localeCompare(a.name)
      }
      return 0
    })

    return (
      <div className="pt-16 section-padding">
        <div className="container-custom">
          <h1 className="text-4xl font-bold text-center mb-12 gradient-text">منتجاتنا</h1>
          
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <Input 
              type="text" 
              placeholder="ابحث عن منتج..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-grow"
            />
            <select 
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
              className="p-2 border rounded-md"
            >
              <option value="default">الترتيب الافتراضي</option>
              <option value="price-asc">السعر: من الأقل للأعلى</option>
              <option value="price-desc">السعر: من الأعلى للأقل</option>
              <option value="name-asc">الاسم: أ-ي</option>
              <option value="name-desc">الاسم: ي-أ</option>
            </select>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    )
  }

  // New Flavors Page Component
  const NewFlavorsPage = () => {
    const newProducts = products.filter(p => p.new)
    const [days, setDays] = useState(0)
    const [hours, setHours] = useState(0)
    const [minutes, setMinutes] = useState(0)
    const [seconds, setSeconds] = useState(0)

    useEffect(() => {
      const countdownDate = new Date('December 31, 2025 23:59:59').getTime()

      const interval = setInterval(() => {
        const now = new Date().getTime()
        const distance = countdownDate - now

        setDays(Math.floor(distance / (1000 * 60 * 60 * 24)))
        setHours(Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)))
        setMinutes(Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)))
        setSeconds(Math.floor((distance % (1000 * 60)) / 1000))

        if (distance < 0) {
          clearInterval(interval)
          setDays(0); setHours(0); setMinutes(0); setSeconds(0);
        }
      }, 1000)

      return () => clearInterval(interval)
    }, [])

    return (
      <div className="pt-16 section-padding">
        <div className="container-custom text-center">
          <h1 className="text-4xl font-bold mb-8 gradient-text">نكهات Balance الجديدة</h1>
          <p className="text-xl text-gray-600 mb-12">استعد لتجربة طعم لا مثيل لها مع أحدث ابتكاراتنا!</p>

          <div className="balance-card p-8 mb-12">
            <h2 className="text-3xl font-bold mb-4 gradient-text">العد التنازلي للإطلاق</h2>
            <div className="flex justify-center items-center gap-4 text-4xl font-bold text-blue-600">
              <div className="flex flex-col items-center">
                <span>{days}</span>
                <span className="text-lg font-normal text-gray-500">أيام</span>
              </div>
              <span>:</span>
              <div className="flex flex-col items-center">
                <span>{hours}</span>
                <span className="text-lg font-normal text-gray-500">ساعات</span>
              </div>
              <span>:</span>
              <div className="flex flex-col items-center">
                <span>{minutes}</span>
                <span className="text-lg font-normal text-gray-500">دقائق</span>
              </div>
              <span>:</span>
              <div className="flex flex-col items-center">
                <span>{seconds}</span>
                <span className="text-lg font-normal text-gray-500">ثواني</span>
              </div>
            </div>
          </div>

          <h2 className="text-3xl font-bold text-center mb-8 gradient-text">اكتشف نكهاتنا الجديدة</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {newProducts.length > 0 ? (
              newProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))
            ) : (
              <p className="col-span-full text-center text-gray-500">لا توجد نكهات جديدة متاحة حاليًا. ترقبوا المزيد قريباً!</p>
            )}
          </div>
        </div>
      </div>
    )
  }

  // About Us Page Component
  const AboutPage = () => (
    <div className="pt-16 section-padding">
      <div className="container-custom">
        <h1 className="text-4xl font-bold text-center mb-12 gradient-text">من نحن</h1>
        <div className="balance-card p-8 mb-8">
          <h2 className="text-3xl font-bold mb-4 text-blue-600">قصتنا</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            تأسست Balance على يد مجموعة من خبراء التغذية وعشاق الطعام في عام 2023، بهدف سد الفجوة بين الوجبات الخفيفة اللذيذة والصحة المتوازنة. بدأنا رحلتنا في البحث والتطوير، مستلهمين من التراث الغذائي الغني لمصر، لتقديم منتجات تجمع بين الطعم الأصيل والقيمة الغذائية العالية.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            في عام 2024، أطلقنا أول خط إنتاج لنا من سناكس البروتين المخبوزة والمطهوة بالهواء، والتي لاقت استحسانًا كبيرًا لجودتها وطعمها الفريد. نحن نؤمن بأن الصحة لا يجب أن تكون على حساب المذاق، ولذلك نلتزم بتقديم منتجات مبتكرة ومغذية تلبي احتياجات المستهلك العصري.
          </p>
        </div>

        <div className="balance-card p-8">
          <h2 className="text-3xl font-bold mb-4 text-blue-600">رؤيتنا وقيمنا</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            **رؤيتنا:** أن نكون الخيار الأول للسناكس الصحية في المنطقة، وأن نلهم الأفراد لتبني أسلوب حياة صحي دون التنازل عن متعة الطعام.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            **قيمنا:**
          </p>
          <ul className="list-disc list-inside text-lg text-gray-700 leading-relaxed pr-5">
            <li>**الابتكار:** نسعى دائمًا لتقديم نكهات ومنتجات جديدة تلبي التطلعات المتغيرة.</li>
            <li>**الجودة:** نلتزم بأعلى معايير الجودة في اختيار المكونات وعمليات التصنيع.</li>
            <li>**الصحة:** نركز على تقديم منتجات غنية بالبروتين والألياف وقليلة الدهون.</li>
            <li>**الشفافية:** نؤمن بتقديم معلومات واضحة وصادقة حول مكوناتنا وقيمنا الغذائية.</li>
            <li>**المسؤولية:** نلتزم بمسؤوليتنا تجاه المجتمع والبيئة.</li>
          </ul>
        </div>
      </div>
    </div>
  )

  // Wholesale Page Component
  const WholesalePage = () => (
    <div className="pt-16 section-padding">
      <div className="container-custom">
        <h1 className="text-4xl font-bold text-center mb-12 gradient-text">الشراء بالجملة</h1>
        <div className="balance-card p-8 mb-8">
          <h2 className="text-3xl font-bold mb-4 text-blue-600">برامج الشراكة</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            نحن نرحب بالتعاون مع الموزعين، تجار التجزئة، والمؤسسات لتقديم منتجات Balance لعملائهم. نقدم برامج شراكة مرنة وأسعارًا تنافسية لدعم نمو أعمالكم.
          </p>
          <ul className="list-disc list-inside text-lg text-gray-700 leading-relaxed pr-5 mb-4">
            <li>خصومات خاصة على الكميات الكبيرة.</li>
            <li>دعم تسويقي ومواد دعائية.</li>
            <li>خدمة عملاء مخصصة لشركائنا.</li>
            <li>توصيل سريع وموثوق.</li>
          </ul>
          <h3 className="text-2xl font-bold mb-4 text-blue-600">شرائح الأسعار</h3>
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full bg-white rounded-lg shadow-md">
              <thead>
                <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">الكمية (كرتون)</th>
                  <th className="py-3 px-6 text-left">الخصم</th>
                  <th className="py-3 px-6 text-left">سعر الوحدة بعد الخصم</th>
                </tr>
              </thead>
              <tbody className="text-gray-600 text-sm font-light">
                <tr className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-3 px-6 text-left whitespace-nowrap">10 - 50</td>
                  <td className="py-3 px-6 text-left">10%</td>
                  <td className="py-3 px-6 text-left">13.45 ج.م</td>
                </tr>
                <tr className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-3 px-6 text-left whitespace-nowrap">51 - 200</td>
                  <td className="py-3 px-6 text-left">15%</td>
                  <td className="py-3 px-6 text-left">12.70 ج.م</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="py-3 px-6 text-left whitespace-nowrap">201+</td>
                  <td className="py-3 px-6 text-left">20%</td>
                  <td className="py-3 px-6 text-left">11.96 ج.م</td>
                </tr>
              </tbody>
            </table>
          </div>

          <h2 className="text-3xl font-bold mb-4 text-blue-600">نموذج طلب الجملة</h2>
          <form className="space-y-4">
            <Input type="text" placeholder="اسم الشركة" required />
            <Input type="text" placeholder="الاسم المسؤول" required />
            <Input type="email" placeholder="البريد الإلكتروني" required />
            <Input type="tel" placeholder="رقم الهاتف" required />
            <Textarea placeholder="الكمية المطلوبة والمنتجات" rows="5" required />
            <Button type="submit" className="balance-button px-6 py-3">إرسال الطلب</Button>
          </form>
        </div>
      </div>
    </div>
  )

  // Contact Us Page Component
  const ContactPage = () => (
    <div className="pt-16 section-padding">
      <div className="container-custom">
        <h1 className="text-4xl font-bold text-center mb-12 gradient-text">تواصل معنا</h1>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="balance-card p-8">
            <h2 className="text-3xl font-bold mb-4 text-blue-600">معلومات الاتصال</h2>
            <div className="space-y-4 text-lg text-gray-700">
              <p className="flex items-center"><MapPin className="h-5 w-5 ml-2 text-blue-600" /> 123 شارع النيل، القاهرة، مصر</p>
              <p className="flex items-center"><Phone className="h-5 w-5 ml-2 text-blue-600" /> +20 100 123 4567</p>
              <p className="flex items-center"><Mail className="h-5 w-5 ml-2 text-blue-600" /> info@balance.com</p>
              <p className="flex items-center"><Clock className="h-5 w-5 ml-2 text-blue-600" /> الأحد - الخميس: 9:00 صباحًا - 5:00 مساءً</p>
            </div>
          </div>
          <div className="balance-card p-8">
            <h2 className="text-3xl font-bold mb-4 text-blue-600">أرسل لنا رسالة</h2>
            <form className="space-y-4">
              <Input type="text" placeholder="اسمك" required />
              <Input type="email" placeholder="بريدك الإلكتروني" required />
              <Input type="text" placeholder="الموضوع" required />
              <Textarea placeholder="رسالتك" rows="5" required />
              <Button type="submit" className="balance-button px-6 py-3">إرسال الرسالة</Button>
            </form>
          </div>
        </div>

        <div className="balance-card p-8 mt-8">
          <h2 className="text-3xl font-bold mb-4 text-blue-600">الأسئلة الشائعة</h2>
          <div className="space-y-4">
            <details className="group">
              <summary className="flex justify-between items-center font-semibold cursor-pointer text-lg text-gray-800">
                ما هي مكونات سناكس Balance؟
                <span className="group-open:rotate-180 transition-transform">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </span>
              </summary>
              <p className="text-gray-600 mt-2 pr-5">
                تُصنع سناكس Balance من مكونات طبيعية عالية الجودة، وهي مخبوزة أو مطهوة بالهواء بدلاً من القلي، مما يجعلها خيارًا صحيًا ولذيذًا.
              </p>
            </details>
            <details className="group">
              <summary className="flex justify-between items-center font-semibold cursor-pointer text-lg text-gray-800">
                هل منتجات Balance خالية من الجلوتين؟
                <span className="group-open:rotate-180 transition-transform">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </span>
              </summary>
              <p className="text-gray-600 mt-2 pr-5">
                بعض منتجاتنا خالية من الجلوتين. يرجى التحقق من وصف المنتج الفردي للحصول على معلومات محددة.
              </p>
            </details>
            <details className="group">
              <summary className="flex justify-between items-center font-semibold cursor-pointer text-lg text-gray-800">
                أين يمكنني شراء منتجات Balance؟
                <span className="group-open:rotate-180 transition-transform">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </span>
              </summary>
              <p className="text-gray-600 mt-2 pr-5">
                منتجات Balance متوفرة في كبرى المتاجر والسوبر ماركت في جميع أنحاء مصر. يمكنك أيضًا العثور عليها عبر الإنترنت من خلال شركائنا المعتمدين.
              </p>
            </details>
          </div>
        </div>
      </div>
    </div>
  )

  // Cart Page Component
  const CartPage = () => (
    <div className="pt-16 section-padding">
      <div className="container-custom">
        <h1 className="text-4xl font-bold text-center mb-12 gradient-text">سلة التسوق</h1>
        {cart.length === 0 ? (
          <div className="text-center text-gray-500 text-xl">
            <p>سلة التسوق فارغة.</p>
            <Button 
              onClick={() => setCurrentPage('products')}
              className="balance-button mt-6 px-6 py-3"
            >
              تسوّق الآن
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              {cart.map(item => (
                <Card key={item.id} className="flex items-center p-4">
                  <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md ml-4" />
                  <div className="flex-grow">
                    <h3 className="font-bold text-lg">{item.name}</h3>
                    <p className="text-gray-600">{item.flavor} • {item.weight_g}جم</p>
                    <p className="text-blue-600 font-semibold">{item.price} ج.م x {item.quantity}</p>
                  </div>
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    onClick={() => removeFromCart(item.id)}
                  >
                    إزالة
                  </Button>
                </Card>
              ))}
            </div>
            <div className="md:col-span-1">
              <Card className="p-6">
                <CardHeader>
                  <CardTitle className="gradient-text">ملخص الطلب</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-lg font-semibold mb-4">
                    <span>الإجمالي:</span>
                    <span>{getCartTotal().toFixed(2)} ج.م</span>
                  </div>
                  <Button className="balance-button w-full py-3">إتمام الشراء</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )

  // Feature Card Component
  const FeatureCard = ({ icon, title, description }) => (
    <Card className="text-center p-6">
      <CardContent className="flex flex-col items-center justify-center p-0">
        <div className="bg-blue-100 text-blue-600 rounded-full p-4 mb-4">
          {icon}
        </div>
        <h3 className="font-bold text-lg mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  )

  // Main App Render
  return (
    <div className="App">
      <Header />
      <main>
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'products' && <ProductsPage />}
        {currentPage === 'new-flavors' && <NewFlavorsPage />}
        {currentPage === 'about' && <AboutPage />}
        {currentPage === 'wholesale' && <WholesalePage />}
        {currentPage === 'contact' && <ContactPage />}
        {currentPage === 'cart' && <CartPage />}
      </main>
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container-custom text-center text-sm">
          <p>&copy; {new Date().getFullYear()} Balance. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  )
}

export default App


